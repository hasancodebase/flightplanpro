import { onRequestGet as __api_wx_js_onRequestGet } from "D:\\flightplanpro\\functions\\api\\wx.js"

export const routes = [
    {
      routePath: "/api/wx",
      mountPath: "/api",
      method: "GET",
      middlewares: [],
      modules: [__api_wx_js_onRequestGet],
    },
  ]